<header>
    <h1 id="websiteName">Corleone Calzone Pizza</h1>
    <img id="websiteLogo" src="../images/carleone%20calzone_LOGO.png" alt="websiteLogo">
    
    <a href="home.php">home</a>
    <a href="shoppingCart.php">winkelwagen</a>
    <a href="profile.php">profiel</a>
</header>