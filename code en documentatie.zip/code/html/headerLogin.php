<!DOCTYPE html>
<html lang="nl">
    <head>
        <meta http-equiv="content-type" content="text/html;charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>corleone calzone pizza</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
        <link rel="icon" type="image/x-icon" href="../images/favicon.ico">
        <link href="../css/style.css" rel="stylesheet">
        <!-- <link href="../css/styleAnouk.css" rel="stylesheet"> -->
        <link href="../css/styleMax.css" rel="stylesheet">
        <link href="../css/styleRoan.css" rel="stylesheet">
    </head>
    <body>
        
        <header>
            <h1 id="websiteNameLogin">Corleone Calzone Pizza</h1>
            <img id="websiteLogoLogin" src="../images/carleone%20calzone_LOGO.png" alt="websiteLogo">
        </header>
        <?php
        if (session_status() === PHP_SESSION_NONE) session_start();
        ?>